Code information://
	Python Version: 3.8//
	IDE used: Spyder (Anaconda)//
Use://
	Go to: https://github.com/lcarr14/Reinforcement_Learning.git
	Download zip and unzip//
	Open "mdp_testing.py"//
	run//
	graphs should generate as program runs through different algorithms, these are the primary tools of analysis//