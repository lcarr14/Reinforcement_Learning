# -*- coding: utf-8 -*-
"""
Created on Sat Nov 27 22:21:46 2021

@author: liamc
"""

import gym
import hiive.mdptoolbox as mh
import numpy as np
import re
import matplotlib.pyplot as plt

def env_gen():
    env = gym.make('FrozenLake8x8-v1')
    env.reset()
    transitions = env.env.P
    actions = int(re.findall(r'\d+', str(env.action_space))[0])
    states = int(re.findall(r'\d+', str(env.observation_space))[0])
    P = np.zeros((actions, states, states))
    R = np.zeros((states, actions))
    nP, nR = convert_PR(states, actions, transitions, P, R)
    return nP, nR

def convert_PR(states, actions, transitions, P, R):
    """Converts the transition probabilities provided by env.P to MDPToolbox-compatible P and R arrays
    """
    for state in range(states):
        for action in range(actions):
            for i in range(len(transitions[state][action])):
                tran_prob = transitions[state][action][i][0]
                state_ = transitions[state][action][i][1]
                R[state][action] += tran_prob*transitions[state][action][i][2]
                P[action, state, state_] += tran_prob
    return P, R

def stat_plot(pi, vi, ql, maxvql):
    pi_rewards = np.zeros(maxvql)
    pi_times = np.zeros(maxvql)
    pi_errors = np.zeros(maxvql)
    for i in range(len(pi)):
        #iterations.append(results[i]['Iteration'])
        pi_rewards[i] = pi[i]['Reward']
        pi_times[i] = pi[i]['Time']
        pi_errors[i] = pi[i]['Max V']
        # pi_rewards.append(pi[i]['Reward'])
        # pi_times.append(pi[i]['Time'])
        # pi_errors.append(pi[i]['Error'])
        
    vi_rewards = np.zeros(maxvql)
    vi_times = np.zeros(maxvql)
    vi_errors = np.zeros(maxvql)
    for i in range(len(vi)):
        #iterations.append(results[i]['Iteration'])
        # vi_rewards.append(vi[i]['Reward'])
        # vi_times.append(vi[i]['Time'])
        # vi_errors.append(vi[i]['Error'])
        vi_rewards[i] = vi[i]['Reward']
        vi_times[i] = vi[i]['Time']
        vi_errors[i] = vi[i]['Max V']
        
    ql_rewards = np.zeros(maxvql)
    ql_times = np.zeros(maxvql)
    ql_errors = np.zeros(maxvql)
    for i in range(len(ql)):
        #iterations.append(results[i]['Iteration'])
        # ql_rewards.append(ql[i]['Reward'])
        # ql_times.append(ql[i]['Time'])
        # ql_errors.append(ql[i]['Error'])
        ql_rewards[i] = ql[i]['Reward']
        ql_times[i] = ql[i]['Time']
        ql_errors[i] = ql[i]['Max V']
        
    
    # pivvi = len(pi_rewards) if len(pi_rewards) > len(vi_rewards) else len(vi_rewards)
    # maxvql = pivvi if pivvi > len(ql_rewards) else len(ql_rewards)
    
    iterations = range(maxvql)
    
    fig, ax = plt.subplots()
    ax.set_xlabel("Iterations")
    ax.set_ylabel("Rewards")
    ax.set_title("Rewards per iteration")
    ax.plot(iterations, pi_rewards, marker='o', label="policy iteration")
    ax.plot(iterations, vi_rewards, marker='o', label="value iteration")
    ax.plot(iterations, ql_rewards, marker='o', label = "Q-learning")
    ax.legend()
    plt.show()
    
    fig, ax = plt.subplots()
    ax.set_xlabel("Iterations")
    ax.set_ylabel("Time (s)")
    ax.set_title("Times per iteration")
    ax.plot(iterations, pi_times, marker='o', label="policy iteration")
    ax.plot(iterations, vi_times, marker='o', label="value iteration")
    ax.plot(iterations, ql_times, marker='o', label = "Q-learning")
    ax.legend()
    plt.show()
    
    fig, ax = plt.subplots()
    ax.set_xlabel("Iterations")
    ax.set_ylabel("Max_V")
    ax.set_title("Max_V per iteration")
    ax.plot(iterations, pi_errors, marker='o', label="policy iteration")
    ax.plot(iterations, vi_errors, marker='o', label="value iteration")
    ax.plot(iterations, ql_errors, marker='o', label = "Q-learning")
    ax.legend()
    plt.show()
    
    return

def run_models(transitions, reward):
    #discount = 0.8
    max_pi = -1
    pi_model = -1
    max_vi = -1
    vi_model = -1
    max_ql = -1
    ql_model = -1
    drs = np.arange(0.1, 0.95, 0.05)
    for i in range(len(drs)):
        pi = mh.mdp.PolicyIteration(transitions, reward, drs[i])
        vi = mh.mdp.ValueIteration(transitions, reward, drs[i])
        ql = mh.mdp.QLearning(transitions, reward, drs[i], alpha=0.3,skip_check=True)
    
        pi.run()
        pi_res = pi.run_stats
        vi.run()
        vi_res = vi.run_stats
        ql.run()
        ql_res = ql.run_stats
        
        if pi_res[-1]['Reward'] > max_pi:
            max_pi = pi_res[-1]['Reward']
            pi_model = pi_res
        if vi_res[-1]['Reward'] > max_vi:
            max_vi = vi_res[-1]['Reward']
            vi_model = vi_res
        if ql_res[-1]['Reward'] > max_ql:
            max_ql = ql_res[-1]['Reward']
            ql_model = ql_res
    print(ql_model)
    
    pivvi = len(pi_model) if len(pi_model) > len(vi_model) else len(vi_model)
    maxvql = pivvi if pivvi > len(ql_model) else len(ql_model)
    
    stat_plot(pi_model, vi_model, ql_model, maxvql)
    return 


def main():
    P,R = env_gen()
    p2,r2 = mh.example.forest(S=500)
    run_models(P,R)
    run_models(p2,r2)
    
    return

if __name__ == "__main__":
    main()